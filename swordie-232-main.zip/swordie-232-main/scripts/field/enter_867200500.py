# id 867200500 (Abrup Basin : Trail to the Village Across the River), field 867200500
sm.createQuestWithQRValue(64006, "WC=0;speed=20;man=200;prog=0;Ec=0;weather=0;max=1;food=450")
sm.createQuestWithQRValue(64006, "WC=0;speed=20;man=200;prog=0;Ec=0;weather=0;max=16;food=450")
sm.startQuest(64033)

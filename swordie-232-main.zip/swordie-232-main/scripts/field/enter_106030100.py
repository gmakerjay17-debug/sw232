# Banquet Hall - Mushroom Castle
if sm.hasQuest(30050):
    sm.completeQuest(30050)
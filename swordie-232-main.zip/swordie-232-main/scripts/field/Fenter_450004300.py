# id 450004900 (Lachelein : Nightmare Clocktower), field 450004900
from net.swordie.ms.constants import BossConstants

sm.spawnMob(BossConstants.LUCID_REWARD_BOX_HARD, -15, 36, False, 200000000)

# id 450005015 (Arcana : Spirit Tree Vantage), field 450005015
sm.lockInGameUI(False, True)

# Dimensional schism : Arkarium's altar (272020210)
from net.swordie.ms.constants import BossConstants

sm.spawnMob(BossConstants.ARKARIUM_EASY, 346, -181, BossConstants.ARKARIUM_EASY_HP)

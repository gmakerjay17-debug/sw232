sm.killMobs()
if sm.hasQuest(2608):
    sm.spawnMob(9300523, -209, 152, False)
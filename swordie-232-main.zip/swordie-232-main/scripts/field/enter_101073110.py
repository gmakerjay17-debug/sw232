# id 101073110 (Mandraky Field : Desolate Orchard 2), field 101073110
sm.setSpeakerType(3)
sm.setParam(4)
sm.setInnerOverrideSpeakerTemplateID(1500019) # Ephony the Fairy
sm.sendSayOkay("Help us! These monsters are gonna eeeeat us!\r\n\r\n#b(Defeat all nearby monsters.)#k")
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)

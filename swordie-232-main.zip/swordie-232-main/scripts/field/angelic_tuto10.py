# id 940011100 (Eastern Region of Pantheon : East Sanctum), field 940011100
sm.lockInGameUI(True, True)
sm.forcedInput(0)
sm.forcedInput(2)
sm.sendDelay(60)
sm.forcedInput(0)
sm.setSpeakerType(3)
sm.setSpeakerID(3000132) # Eskalade
sm.setParam(17)
sm.sendNext("Okay, dragon-guy, we're here. ")
sm.setParam(1)
sm.sendSay("Do you see a ring where the relic used to be?")
sm.forcedInput(2)

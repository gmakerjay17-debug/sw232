# id 940200300 (Cavern : Deep Within the Cavern 1), field 940200300
sm.showFieldEffect("aswan/stageEff/stage", 0)
sm.showFieldEffect("aswan/stageEff/number/1", 0)
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)

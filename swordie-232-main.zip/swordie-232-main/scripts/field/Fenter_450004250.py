# id 450004250 (Lachelein : Crumbling Clocktower), field 450004250
from net.swordie.ms.constants import BossConstants

sm.spawnMob(BossConstants.LUCID_TEMPLATE_ID_2, 600, -500, False, BossConstants.LUCID_HP_2)
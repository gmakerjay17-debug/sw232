# id 101073010 (Mandraky Field : Desolate Orchard 1), field 101073010
sm.setSpeakerType(3)
sm.setParam(4)
sm.setInnerOverrideSpeakerTemplateID(1500017) # Tosh the Fairy
sm.sendSayOkay("Help me! I'm totally stuck 'cuz of all the monsters!\r\n\r\n#b(Defeat all nearby monsters.)#k")
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)

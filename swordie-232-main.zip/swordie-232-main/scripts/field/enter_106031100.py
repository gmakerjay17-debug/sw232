# id 106031100 (Direction : Direction), field 106031100
sm.lockInGameUI(True, False)
sm.hideUser(True)
sm.forcedInput(0)
sm.sendDelay(3500)
sm.sendDelay(9500)
sm.reservedEffect(False, 0, 0, "Effect/Direction2.img/flowervioleta/opennig")
sm.lockInGameUI(False, True)
sm.warp(106031000)

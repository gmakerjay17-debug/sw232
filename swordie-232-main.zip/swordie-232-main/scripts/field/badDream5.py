# id 913051004 (Hidden Street : Present Ereve), field 913051004
sm.lockInGameUI(True, True)
sm.hideUser(True)
sm.showFieldEffect("twilightPerion/text6", 0)
sm.sendDelay(2500)
sm.setSpeakerType(3)
sm.setSpeakerID(2142910) # Kirium
sm.setParam(1)
sm.sendNext("You're having the dream as well?")
sm.setSpeakerID(2142911) # Kiriwing
sm.sendSay("It's strange. Everyone having nightmares.")
sm.setSpeakerID(2142912) # Kiryu
sm.sendSay("We have Empress Cygnus here to ground our fears, but what about people in other areas?")
sm.hideUser(False)
sm.lockInGameUI(False, True)
sm.warp(913051005)

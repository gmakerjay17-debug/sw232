# id 701220100 (Shaolin Temple : Sutra Depository 1-2 F), field 701220100
sm.playSound("Sound/FarmSE.img/boxResult", 100)
sm.createFieldTextEffect("#fs20#Sutra Depository Floors 1-2", 100, 2500, 5, 80, 0, 1, 4, 0, 0, 0)

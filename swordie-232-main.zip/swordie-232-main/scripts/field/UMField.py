# id 913050010 (Ereve : Conference Room of the Alliance), field 913050010
sm.createQuestWithQRValue(18418, "B=3335")

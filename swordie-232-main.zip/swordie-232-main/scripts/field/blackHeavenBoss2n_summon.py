# 350060800 - Normal mode
from net.swordie.ms.constants import BossConstants

LOTUS = 8950101
mob = sm.spawnMob(LOTUS, 370, -16, BossConstants.LOTUS_NORMAL_HP_2)  # 750b
sm.showHP(LOTUS)

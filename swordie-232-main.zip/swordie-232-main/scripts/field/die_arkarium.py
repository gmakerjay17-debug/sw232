# 8644419
sm.completeQuest(34268)
sm.createQuestWithQRValue(34271, "34=h0;34=h1")
sm.warpInstanceOut(450006440)
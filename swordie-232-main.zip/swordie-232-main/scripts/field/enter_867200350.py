# id 867200350 (Abrup Basin : Burning Kaptafel), field 867200350
sm.createQuestWithQRValue(16119, "")
sm.createQuestWithQRValue(16150, "")

# id 450001400 (Nina's Erda Investigation : Within the Land of Oblivion), field 450001400
sm.progressMessageFont(3, 20, 0, 0, "The Erda Collector has been activated. When hit, Erda will materialize nearby.")

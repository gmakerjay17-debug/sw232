# Fritto - Eagle FPS stage

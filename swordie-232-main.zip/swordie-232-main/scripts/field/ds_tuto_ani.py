sm.lockInGameUI(True)
sm.playVideoByScript("DemonSlayer1.avi")# DemonSlayer2.avi for female

sm.warpInstanceIn(931050000, 0)


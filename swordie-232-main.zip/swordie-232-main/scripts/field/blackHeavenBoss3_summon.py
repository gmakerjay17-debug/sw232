from net.swordie.ms.constants import BossConstants

# 350060500 - Hard mode
LOTUS = 8950102
sm.spawnMob(LOTUS, 370, -16, BossConstants.LOTUS_HARD_HP_3)  # 15T
sm.showHP(LOTUS)


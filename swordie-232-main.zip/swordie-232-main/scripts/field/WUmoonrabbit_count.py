# field 933001000 | (Moon Bunny's Rice Cake : Primrose HIll)
STAGE_1_CLEARED = "Stage1Cleared"
STAGE_1_FLOWER_DATA = "Stage1FlowerData"
field.setProperty(STAGE_1_FLOWER_DATA, 0)
field.setProperty(STAGE_1_CLEARED, False)
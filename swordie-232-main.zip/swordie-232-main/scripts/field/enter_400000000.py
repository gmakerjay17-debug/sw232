# id 400000000 (Nova's Sanctum : Pantheon), field 400000000
sm.startQuest(11620)
sm.createQuestWithQRValue(15710, "lasttime=19/07/16/06/17")

# id 101020401 (East Forest : Windy Place), field 101020401
sm.createQuestWithQRValue(16700, "count=92;date=20190716")
sm.createQuestWithQRValue(16700, "count=93;date=20190716")
sm.createQuestWithQRValue(16700, "count=94;date=20190716")
sm.createQuestWithQRValue(16700, "count=95;date=20190716")
sm.createQuestWithQRValue(16700, "count=96;date=20190716")

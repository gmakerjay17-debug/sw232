sm.lockInGameUI(True)

sm.removeEscapeButton()
sm.flipDialoguePlayerAsSpeaker()
sm.sendNext("This place is frighteningly well-preserved. Now where did I put that skill book? The small cabinet with the world's first meso? The trunk with the only existing Reverse Miracle Cube?")
sm.lockInGameUI(False)
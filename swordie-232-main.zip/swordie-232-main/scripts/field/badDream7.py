# id 913051006 (Hidden Street : Recent Perion), field 913051006
sm.lockInGameUI(True, True)
sm.hideUser(True)
sm.showFieldEffect("twilightPerion/text8", 0)
sm.sendDelay(2500)
sm.setSpeakerType(3)
sm.setSpeakerID(2142921) # Dances with Balrog
sm.setParam(1)
sm.sendNext("The same dream for days on end... It's unbelievable.")
sm.setSpeakerID(2142922) # Stands with Bulls
sm.sendSay("This is simple trickery from the enemy! They're trying to make us lose faith in each other.")
sm.setSpeakerID(2142923) # Ayan
sm.sendSay("But the people of town are so scared... especially with these strange rumors.")
sm.setSpeakerID(2142920) # Blackbull
sm.sendSay("Isn't this a bad omen?")
sm.hideUser(False)
sm.lockInGameUI(False, True)
sm.warp(913051007)

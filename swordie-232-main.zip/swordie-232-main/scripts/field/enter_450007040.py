if sm.hasQuestCompleted(34585) and sm.hasQuestCompleted(34584) and not sm.hasQuestCompleted(34586):
    sm.completeQuest(34586)
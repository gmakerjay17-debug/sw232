# Root Abyss | Abyssal Cave  (Vellum's Boss Map)

from net.swordie.ms.enums import WeatherEffNoticeType

sm.showWeatherNotice("Vellum is nowhere to be seen. Let's take a look around the altar.", WeatherEffNoticeType.SnowySnowAndSprinkledFlowerAndSoapBubbles, 10000)
# id 867200110 (Abrup Basin : Base Camp), field 867200110
sm.lockInGameUI(False, True)
sm.setMapTaggedObjectVisible("go64014", False, 0, 0)

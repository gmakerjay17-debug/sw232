# Curbrock Scene 2

sm.showFieldEffect("Map/Effect.img/Curbrock1/frame")
sm.showFieldEffect("Map/Effect.img/Curbrock1/002")
#Enter Goo Island: Goo Ruins 4th floor
from net.swordie.ms.enums import ActionBarType
sm.setActionBar(True, ActionBarType.GooExploration)
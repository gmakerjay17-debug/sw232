from net.swordie.ms.constants import BossConstants
sm.spawnMob(BossConstants.VERUS_HILLA, 370, 266, BossConstants.VERUS_HILLA_HP)
# id 867200260 (Abrup Basin : Kaptafel Outskirts), field 867200260
sm.createQuestWithQRValue(64014, "scene1=1;scene2=1;scene4=0;mapIdx=0")
sm.showFieldEffect("monsterPark/stageEff/stage", 0)
sm.showFieldEffect("monsterPark/stageEff/number/4", 0)

# id 450002250 (Chu Chu Island : Slurpy Tree Habitat), field 450002250
sm.spawnMob(8642016, 528, 138)
# Fritto Eagle enter user script
sm.chat("This has not been coded yet :(")
sm.warp(993000601)
sm.dispose()
# id 610050100 (null), field 610050100
sm.playSound("Sound/FarmSE.img/boxResult", 100)

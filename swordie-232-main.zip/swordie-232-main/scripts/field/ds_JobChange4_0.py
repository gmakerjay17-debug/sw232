# 927000100 | demon slayer 4th job adv
sm.spawnMob(9001039, 524, 69, False)
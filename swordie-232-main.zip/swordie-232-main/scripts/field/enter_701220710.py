# id 701220710 (Shaolin Temple : Sutra Depository - Top), field 701220710
sm.createQuestWithQRValue(62040, "eNum=1;DlastDate=19/06/25;lastDate=19/06/25")
sm.createQuestWithQRValue(62040, "eNum=1;Dcount=1;DlastDate=19/06/25;lastDate=19/06/25")
sm.createQuestWithQRValue(62042, "clear=0")
sm.createQuestWithQRValue(62042, "clear=1")

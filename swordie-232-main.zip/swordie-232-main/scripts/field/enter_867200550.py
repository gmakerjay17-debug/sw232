# id 867200550 (Abrup Basin : Svarti Trail), field 867200550
sm.createQuestWithQRValue(64006, "WC=0;k1=0;k2=0;k3=0;speed=20;man=199;prog=0;Pt=CaravanP1_chk15;Ec=0;max=1;weather=0;food=320")
sm.createQuestWithQRValue(64006, "WC=0;k1=0;k2=0;k3=0;speed=20;man=199;prog=0;Pt=CaravanP1_chk15;Ec=0;max=20;weather=0;food=320")

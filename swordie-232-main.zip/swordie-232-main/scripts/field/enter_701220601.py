# id 701220601 (Shaolin Temple : Sutra Depository - Top), field 701220601
sm.progressMessageFont(3, 20, 13, 0, "Follow the Chief Priest through the portal on the right.")

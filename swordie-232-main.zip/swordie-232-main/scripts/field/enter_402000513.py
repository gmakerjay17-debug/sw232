# id 402000513 (null), field 402000513
sm.setSpeakerType(3)
sm.setParam(37)
sm.setColor(1)
sm.setInnerOverrideSpeakerTemplateID(3001310) # Morian
sm.sendNext("#face0#Hey! Look! Carnelian's here!")
sm.setInnerOverrideSpeakerTemplateID(3001350) # Illium
sm.sendSay("#face0##b(She doesn't look so good... I hope she's not injured.)#k")

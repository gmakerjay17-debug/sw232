# id 940012000 (Hidden Street : First Transformation), field 940012000
sm.lockInGameUI(True, False)
sm.sendDelay(6600)
sm.reservedEffect(False, 0, 0, "Effect/Direction10.img/angelicTuto/Scene2")
sm.lockInGameUI(False, True)
sm.warp(940011110)

# Gigantic Excavator Drill
# 600010250
# User enter script
# Spawns a Cerberusian Gigantic Drill for You Know the Drill.

gigaDrill = 9601293

sm.spawnMob(gigaDrill, 565, 47, False)
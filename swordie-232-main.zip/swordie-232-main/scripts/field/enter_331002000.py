# id 331002000 (School for the Gifted : First Floor Corridor), field 331002000
sm.lockInGameUI(False, True)
sm.createFieldTextEffect("#fnﾳﾪﾴﾮﾰ￭ﾵ￱ ExtraBold##fs26#First Floor: Corridor\r\n #fs14#- Private School for the Gifted -", 100, 2500, 4, 0, 0, 1, 4, 0, 0, 0)

# id 331003000 (Subway : Subway Car #1), field 331003000
sm.showNpcSpecialActionByTemplateId(1531064, "summon", 0)
sm.playSound("Sound/Field.img/flowervioleta/wink", 100)
sm.lockInGameUI(False, True)

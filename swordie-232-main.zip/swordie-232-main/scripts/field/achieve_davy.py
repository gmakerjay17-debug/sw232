# Maps in Lord PiratePQ  | Used in the  Lord Pirate PQ
if sm.getFieldID() == 925100500 and not sm.hasMobsInField():
    sm.spawnMob(9300119, 566, 238, False) # Spawns  Captain Davy John
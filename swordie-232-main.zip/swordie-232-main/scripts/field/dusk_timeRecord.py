# Moonbridge: Eye of the Void
# 450009400
# Boss: Gloom

#  sm.spawnMob(8644650, -45, -157, 26000000000000) # 26T
# from net.swordie.ms.constants import BossConstants
#
# difficulty = 4
# if sm.getChr().getInstance().getField(863010240).hasProperty(BossConstants.GOLLUX_FINISHED_KEY):
#     difficulty -= 1
# if sm.getChr().getInstance().getField(863010430).hasProperty(BossConstants.GOLLUX_FINISHED_KEY):
#     difficulty -= 1
# if sm.getChr().getInstance().getField(863010330).hasProperty(BossConstants.GOLLUX_FINISHED_KEY):
#     difficulty -= 1
#
# golluxRewardMob = 9601458 + difficulty
#
# sm.spawnMob(golluxRewardMob, 93, 74)
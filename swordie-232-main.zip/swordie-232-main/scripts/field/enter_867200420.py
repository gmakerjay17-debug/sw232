# id 867200420 (Abrup Basin : Eyeful Territory), field 867200420
sm.setSpeakerType(3)
sm.setParam(37)
sm.setColor(1)
sm.setInnerOverrideSpeakerTemplateID(9400589) # Peytour
sm.sendNext("#face0#Hunt these Petreefied Eyeful monsters and bring back 50 pieces of Sturdy Wood. ")
sm.sendSay("#face0#I must say, these creatures are very clever in hoarding Sturdy Wood. ")
sm.sendSay("#face0#But ours is the greater need right now, so we will do what must be done. ")
sm.setInnerOverrideSpeakerTemplateID(9400582) # Cayne
sm.sendSay("#face0#Not a problem! Have at you, foul wood-hoarding beasts! ")
sm.warp(867200419)

sm.spawnReactor(2408000, 933, -340)
sm.createStopWatch(30)  # 30 sec
sm.invokeAfterDelay(30000, "warpInstanceOut", 993000601, 0)

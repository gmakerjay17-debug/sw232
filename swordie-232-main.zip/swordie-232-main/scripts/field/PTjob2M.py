LOCK = 9001045
if sm.hasQuest(25100):
    sm.spawnMob(LOCK, 170, 182, False)
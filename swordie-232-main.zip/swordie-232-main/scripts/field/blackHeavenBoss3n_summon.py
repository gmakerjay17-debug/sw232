from net.swordie.ms.constants import BossConstants

# 350060900 - Normal mode
LOTUS = 8950002
sm.spawnMob(LOTUS, 370, -16, BossConstants.LOTUS_NORMAL_HP_3)  # 1T
sm.showHP(LOTUS)
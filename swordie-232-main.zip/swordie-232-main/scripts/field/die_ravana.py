# 8800200
if sm.hasQuest(3863):
    sm.completeQuestNoRewards(3863) # Ravana the Demon
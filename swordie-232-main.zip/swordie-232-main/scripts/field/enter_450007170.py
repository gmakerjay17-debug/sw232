# id 450007170 (Esfera : Slumbering Deep), field 450007170
sm.setMapTaggedObjectVisible("450007170_tana", False, 0, 0)
sm.setMapTaggedObjectVisible("450007170_tana", False, 0, 0)

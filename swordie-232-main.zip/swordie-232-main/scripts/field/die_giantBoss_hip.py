# 9390612
from net.swordie.ms.constants import BossConstants

field.setProperty(BossConstants.GOLLUX_FINISHED_KEY, True)
sm.showGolluxMiniMap()
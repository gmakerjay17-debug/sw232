# id 450005400 (Arcana : Cavernous Cavern), field 450005400
sm.startQuest(28825)

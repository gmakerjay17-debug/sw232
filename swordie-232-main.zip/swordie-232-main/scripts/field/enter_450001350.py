# id 450001350 (Hidden Street : Cave of Repose Exit), field 450001350
sm.createQuestWithQRValue(34125, "350=2;370=2;380=2;390=2;300=2;310=2;320=2;330=2;340=2")
sm.lockInGameUI(True, False)
equips = [1442277, ]
sm.avatarLookSet(equips)
sm.lockInGameUI(False, True)
sm.progressMessageFont(3, 20, 8, 0, "The way out of the Cave of Repose is to the right. Help Kao and escape the cave.")

# id 867236200 (Abrup Basin : Skuas Castle Tower), field 867236200
sm.lockInGameUI(True, False)
sm.forcedInput(0)
sm.zoomCamera(2000, 1000, 2000, 206, -410)
sm.sendDelay(2000)
sm.lockInGameUI(False, True)
sm.createQuestWithQRValue(16119, "")
sm.createQuestWithQRValue(16150, "")

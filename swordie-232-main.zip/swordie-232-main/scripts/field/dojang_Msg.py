# Mu Lung Dojo Entrance (925020000) | Used for dojo weather notice

from net.swordie.ms.enums import WeatherEffNoticeType

sm.showWeatherNotice("If you want to taste the bitterness of defeat, come on in!", WeatherEffNoticeType.MuLungDojo)
sm.dispose()

# 8880150
import time
sm.showFieldEffect("quest/party/clear", 0)
sm.playSound("Party1/Clear", 100)
time.sleep(5)
sm.warpField(450004300, 0)
# id 301050200 (Hidden Street : Mini-game: Castle Climb), field 301050200
sm.createQuestWithQRValue(16119, "")
sm.createQuestWithQRValue(16150, "")

# field 933011000 | First time together <Stage 1>

from net.swordie.ms.enums import WeatherEffNoticeType

sm.showWeatherNotice("Everyone! Talk to Cloto, and defeat Ligators to find the coupons Cloto wants!", WeatherEffNoticeType.KerningPQ, 5000)
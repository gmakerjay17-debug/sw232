# id 331000000 (Main Street : City Center), field 331000000
sm.changeBGM("Bgm43/Unknown Part Of City", 0, 0)

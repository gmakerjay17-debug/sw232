# id 450001380 (Hidden Street : Split Road of Destiny), field 450001380
sm.warp(450001340)
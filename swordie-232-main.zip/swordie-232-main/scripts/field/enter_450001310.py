# id 450001310 (Hidden Street : Lake of Oblivion), field 450001310
sm.createQuestWithQRValue(34125, "310=2")
sm.lockInGameUI(True, False)
sm.sendDelay(10)
sm.removeAdditionalEffect()
sm.progressMessageFont(3, 20, 8, 0, "You can use the directional keys to steer the boat.")
sm.sendDelay(500)
sm.lockInGameUI(False, True)

# id 101073300 (Mandraky Field : Outdoor Theater Stage), field 101073300
sm.setSpeakerType(3)
sm.setParam(4)
sm.setInnerOverrideSpeakerTemplateID(1500016) # Woonie the Fairy
sm.sendSayOkay("Please eliminate that gross old mole!\r\n#b(Defeat the Mole King.)#k")
sm.startQuest(26509)
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)

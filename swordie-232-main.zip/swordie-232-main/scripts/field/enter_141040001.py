# id 141040001 (Riena Strait : Frostwitch Barbara), field 141040001
sm.setSpeakerType(3)
sm.setParam(5)
sm.setInnerOverrideSpeakerTemplateID(9010000) # Maple Administrator
res = sm.sendAskYesNo("Would you like to skip the cutscenes?")
sm.warp(141040002)

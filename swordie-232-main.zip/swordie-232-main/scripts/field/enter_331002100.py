# id 331002100 (School for the Gifted : Second Floor Corridor), field 331002100
sm.lockInGameUI(False, True)
sm.createFieldTextEffect("#fnﾳﾪﾴﾮﾰ￭ﾵ￱ ExtraBold##fs26#Second Floor: Corridor\r\n #fs14#- Private School for the Gifted -", 100, 2500, 4, 0, 0, 1, 4, 0, 0, 0)

# id 867200860 (Abrup Basin : Abandoned Village Outskirts), field 867200860
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)
sm.createQuestWithQRValue(64040, "chk1=1")
sm.warp(867200859)

# Aran Introduction
sm.killMobs()

if sm.getFieldID() == 914000200:
    sm.spawnMob(9300379, 2099, 2, False, 10)
    sm.spawnMob(9300379, 1799, 2, False, 10)
    sm.spawnMob(9300379, 1515, 2, False, 10)

elif sm.getFieldID() == 914000210:
    sm.spawnMob(9300380, 667, 2, False, 15)
    sm.spawnMob(9300380, 382, 2, False, 15)
    sm.spawnMob(9300380, 97, 2, False, 15)

elif sm.getFieldID() == 914000220:
    sm.spawnMob(9300381, -716, 2, False, 20)
    sm.spawnMob(9300381, -839, 2, False, 20)
    sm.spawnMob(9300381, -1046, 2, False, 20)
    sm.spawnMob(9300381, -1186, 2, False, 20)
    sm.spawnMob(9300381, -1332, 2, False, 20)
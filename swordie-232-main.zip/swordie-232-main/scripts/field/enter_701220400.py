# id 701220400 (Shaolin Temple : Sutra Depository 7-8 F), field 701220400
sm.playSound("Sound/FarmSE.img/boxResult", 100)
sm.createFieldTextEffect("#fs20#Sutra Depository Floors 7-8", 100, 2500, 5, 80, 0, 1, 4, 0, 0, 0)

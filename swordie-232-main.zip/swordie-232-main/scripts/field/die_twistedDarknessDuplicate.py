#Twisted Darkness Duplicate death script
field.setProperty("killed", True)
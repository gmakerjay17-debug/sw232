# id 101082000 (Ruenna's Home : 1st Floor Living Room), field 101082000
sm.lockInGameUI(True, False)
sm.blind(True, 150, 0, 0, 0, 1000)
sm.sendDelay(1000)
sm.lockInGameUI(False, True)

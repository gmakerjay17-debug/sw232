sm.lockInGameUI(True)
sm.curNodeEventEnd(True)
sm.forcedInput(2)

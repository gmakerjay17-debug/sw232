# # #
# San Commerci : En Route
#
# Field Ids:    865000100
#               865000200
#               865000300
#               865000400
#               865000501
#               865000900
#

sm.setDeathCount2(1)
sm.finishVoyageHorde()

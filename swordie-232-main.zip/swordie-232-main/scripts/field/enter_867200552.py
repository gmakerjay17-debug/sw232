# id 867200552 (Abrup Basin : Svarti Entrance), field 867200552
sm.createQuestWithQRValue(64006, "WC=9;k1=0;k2=0;k3=0;k4=0;k5=0;speed=40;k6=0;k7=0;man=239;prog=0;Pt=CaravanP2_chk19;Ec=20;max=20;weather=1;food=90")

#Enter Goo Island: Goo Ruins 1st floor
from net.swordie.ms.enums import ActionBarType
#sm.invokeForParty("setActionBar", True, ActionBarType.GooExploration)

sm.setActionBar(True, ActionBarType.GooExploration)
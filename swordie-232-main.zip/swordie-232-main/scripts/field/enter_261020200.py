# Lab - Area B-1
# 261020200
# User enter script
# Outputs help text for [Magatia's Secret] Life Alchemy, and the Missing Alchemist.

lifeAlchemyMissing = 3314

if sm.hasQuest(lifeAlchemyMissing):
    sm.progressMessageFont(3, 20, 8, 0, "Click Russellon's Desk to obtain the new medicine.")
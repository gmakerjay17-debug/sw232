sm.lockInGameUI(False)
# DAFQ nexon ?
sm.completeQuestNoRewards(23200)
sm.deleteQuest(23200)
sm.completeQuestNoRewards(23201)
sm.deleteQuest(23201)
sm.completeQuestNoRewards(23202)
sm.deleteQuest(23202)

# id 867200330 (Abrup Basin : Burning Guard Post), field 867200330
sm.createQuestWithQRValue(64015, "chk1=1;chk2=1;slaDir=1;chk3=1;chk4=1;chk5=1;chk6=1;chk7=1;chk8=0")
sm.showNpcSpecialActionByTemplateId(9400580, "summon", 0)
sm.showNpcSpecialActionByTemplateId(9400593, "summon", 0)
sm.showNpcSpecialActionByTemplateId(9400595, "summon", 0)

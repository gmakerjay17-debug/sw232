# id 701220300 (Shaolin Temple : Sutra Depository 5-6 F), field 701220300
sm.playSound("Sound/FarmSE.img/boxResult", 100)
sm.createFieldTextEffect("#fs20#Sutra Depository Floors 5-6", 100, 2500, 5, 80, 0, 1, 4, 0, 0, 0)

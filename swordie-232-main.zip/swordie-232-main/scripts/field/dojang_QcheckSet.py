DOJO_QUEST = 3887
sm.setSpeakerID(2091011)
sm.sendSayOkay("Not bad. Keep on trying \r\n\r\n#b-Cleared floor: Floor "+str(sm.getQRValue(DOJO_QUEST, "floor"))+"\r\n-Time taken: "+str(sm.getQRValue(DOJO_QUEST, "time")) + " sec")
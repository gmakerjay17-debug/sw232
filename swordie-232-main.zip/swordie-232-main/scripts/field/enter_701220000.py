# Shaolin Temple : Mahavira Hall
sm.showEffect("Effect/EffectCN.img/shaolin/title")
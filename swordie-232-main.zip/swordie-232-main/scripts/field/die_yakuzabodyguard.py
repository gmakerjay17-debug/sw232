# When Yakuza Bodyguard (9400112) dies
# Spawns a Yakuza Protector
sm.spawnMob(9400113, mob.getPosition().getX(), mob.getPosition().getY())

# id 450001320 (Hidden Street : Fire Zone Cliff), field 450001320
sm.progressMessageFont(3, 20, 8, 0, "Climb up the cliff.")
sm.lockInGameUI(True, False)
sm.removeAdditionalEffect()
sm.forcedInput(7)
sm.forcedInput(3)
sm.sendDelay(50)
sm.forcedInput(0)
sm.lockInGameUI(False, True)

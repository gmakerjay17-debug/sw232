# id 867200800 (Abrup Basin : Abandoned Village), field 867200800
sm.showNpcSpecialActionByTemplateId(9400581, "summon", 0)
sm.showNpcSpecialActionByTemplateId(9400585, "summon", 0)
sm.showNpcSpecialActionByTemplateId(9400582, "summon", 0)

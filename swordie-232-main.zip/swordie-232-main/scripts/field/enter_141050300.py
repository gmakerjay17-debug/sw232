# id 141050300 (Riena Strait : Glacier Cutter), field 141050300
sm.startQuest(26512)

# 8880301, 8880341
import time
time.sleep(5)
sm.warpField(field.getId() + 100)
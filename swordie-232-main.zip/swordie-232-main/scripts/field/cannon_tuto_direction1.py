sm.lockInGameUI(True)
sm.playSound("cannonshooter/flying", 100)
sm.showEffect("Effect/Direction4.img/effect/cannonshooter/balloon/0", 9000, 0, 0, 0, -2, False, 0)
sm.sendDelay(1500)

sm.showEffect("Effect/Direction4.img/effect/cannonshooter/balloon/1", 9000, 0, 0, 0, -2, False, 0)
sm.sendDelay(1500)

sm.showEffect("Effect/Direction4.img/effect/cannonshooter/balloon/2", 9000, 0, 0, 0, -2, False, 0)
sm.reservedEffect("Effect/Direction4.img/cannonshooter/face04")
sm.reservedEffect("Effect/Direction4.img/cannonshooter/out01")
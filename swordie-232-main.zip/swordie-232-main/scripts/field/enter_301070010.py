# id 301070010 (Crimsonheart Castle : Path to the Altar), field 301070010
sm.startQuest(31258)
sm.startQuest(31258)

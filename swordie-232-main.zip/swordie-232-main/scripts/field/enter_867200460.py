# id 867200460 (Abrup Basin : Kaptafel Outskirts), field 867200460
sm.startQuest(28825)

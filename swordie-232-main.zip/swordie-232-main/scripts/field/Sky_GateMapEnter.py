# id 240080000 (Leafre : Crimson Sky Dock), field 240080000
sm.createQuestWithQRValue(15794, "beforelv=211")
sm.createQuestWithQRValue(18418, "B=34970")

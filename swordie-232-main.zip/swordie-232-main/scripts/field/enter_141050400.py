# id 141050400 (Riena Strait : Admiral Martini), field 141050400
sm.setSpeakerType(3)
sm.setParam(5)
sm.setInnerOverrideSpeakerTemplateID(9010000) # Maple Administrator
res = sm.sendAskYesNo("Would you like to skip the cutscenes?")
sm.warp(141050000)

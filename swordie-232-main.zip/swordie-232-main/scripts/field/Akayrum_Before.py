# Dimensional schism : Arkarium's altar (272020200)
from net.swordie.ms.constants import BossConstants

sm.spawnMob(BossConstants.ARKARIUM_NORMAL, 346, -181, BossConstants.ARKARIUM_NORMAL_HP)
# id 867201050 (Abrup Basin : Svarti Entrance), field 867201050
sm.lockInGameUI(False, True)
sm.setMapTaggedObjectVisible("close", False, 0, 0)

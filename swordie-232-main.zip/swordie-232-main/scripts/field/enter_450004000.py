# id 450004000 (Lachelein : Nightmare Clocktower), field 450004000
sm.showNpcSpecialActionByTemplateId(3003200, "summon", 0)

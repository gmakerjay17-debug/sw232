# id 331003300 (Subway : Subway Car #4), field 331003300
sm.lockInGameUI(False, True)
sm.createQuestWithQRValue(22700, "V01=1;V02=1;q21end=0;coNight=0;kinePro=0;kinetuto=1;kinetuto2=1;E1=1;blackCat=0;E2=1;E3=1")
sm.playSound("Sound/Field.img/flowervioleta/wink", 100)
sm.createQuestWithQRValue(16700, "count=89;date=20190716")
sm.createQuestWithQRValue(16700, "count=90;date=20190716")
sm.createQuestWithQRValue(16700, "count=91;date=20190716")
sm.createQuestWithQRValue(22701, "kinePro=1")
sm.showFieldEffect("monsterPark/clearF", 0)

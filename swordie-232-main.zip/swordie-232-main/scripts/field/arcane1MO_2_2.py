# id 450001500 (Nina's Erda Investigation : Within the Land of Tranquility), field 450001500
sm.progressMessageFont(3, 20, 9, 0, "The Erda must have attracted them. There was a quick ripple of red light, but then nothing...")

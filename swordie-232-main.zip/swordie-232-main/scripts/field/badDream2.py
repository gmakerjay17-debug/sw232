# id 913051001 (Hidden Street : Future Henesys), field 913051001
sm.lockInGameUI(True, True)
sm.moveCamera(False, 200, 1709, 205)
sm.sendDelay(15000)
sm.lockInGameUI(False, True)
sm.warp(913051002)

# id 331001000 (Hideout : HQ), field 331001000
sm.setSpeakerType(3)
sm.setParam(36)
sm.setColor(1)
sm.setInnerOverrideSpeakerTemplateID(1531001) # Jay
sm.sendNext("Good job. Get up to the 2nd floor.")
sm.lockInGameUI(False, True)

# id 867200220 (Abrup Basin : Beaknose Cliff), field 867200220
sm.createQuestWithQRValue(64014, "scene1=1;scene2=0;mapIdx=0")
sm.showFieldEffect("monsterPark/stageEff/stage", 0)
sm.showFieldEffect("monsterPark/stageEff/number/2", 0)
sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)

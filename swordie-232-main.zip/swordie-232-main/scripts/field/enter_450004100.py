# id 450004700 (Lachelein : Nightmare Clocktower), field 450004700
sm.lockInGameUI(True, False)
sm.blind(True, 255, 0, 0, 0, 0)
sm.spineScreen(True, False, True, 0, "Map/Effect3.img/BossLucid/Lucid/lusi","animation","")
sm.playSound("Sound/SoundEff.img/ArcaneRiver/lucid_spine", 200)
sm.sendDelay(9000)
sm.lockInGameUI(False, True)
sm.lockInGameUI(False, True)
sm.warp(450004750)

# id 400000001 (Pantheon : Great Temple Interior), field 400000001
sm.startQuest(11620)
sm.createQuestWithQRValue(15710, "lasttime=19/07/16/06/21")

# 927000100 | demon slayer 4th job adv
sm.removeEscapeButton()
sm.setPlayerAsSpeaker()
sm.spawnNpc(2159335, 377, 69)
sm.sendNext("#b(I remember the feeling of unleashing my Fury... But I can't hold onto it for long...)")
sm.spawnMob(9001041, 377, 69, False)
sm.removeNpc(2159335)
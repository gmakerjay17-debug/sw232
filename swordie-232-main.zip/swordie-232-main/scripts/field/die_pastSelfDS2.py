# 9001041
sm.addQRValue(23206, "1")
sm.warpInstanceOut(310010000)
sm.lockInGameUI(True)
sm.forcedInput(1)
sm.sendDelay(30)

sm.forcedInput(0)
sm.showFieldEffect("demonSlayer/text13", 0)
sm.sendDelay(500)

sm.showFieldEffect("demonSlayer/text14", 0)
sm.sendDelay(4000)

sm.lockInGameUI(False)
sm.warpInstanceIn(927000020, 0)


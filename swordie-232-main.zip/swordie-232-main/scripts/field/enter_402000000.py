# id 402000000 (null), field 402000000
sm.setMapTaggedObjectVisible("crack", False, 0, 0)

sm.showFieldEffect("resistance/tutorialGuide")
sm.createQuestWithQRValue(23007, "")
# User enter script
# Plays a *loud* boat whistle sound effect.

sm.playSound("advStory/whistle")
# id 867200920 (Abrup Basin : Windsnap River Bank), field 867200920
sm.createQuestWithQRValue(64034, "")
sm.startQuest(64161)
sm.startQuest(64166)
sm.startQuest(64165)
sm.createQuestWithQRValue(16119, "")
sm.createQuestWithQRValue(16150, "")

sm.showFieldEffect("monsterPark/clear", 0)
sm.playSound("Party1/Clear", 100)
#Hotel Arcus Saloon
if not sm.hasQuestCompleted(38120):
    sm.completeQuestNoCheck(38120)
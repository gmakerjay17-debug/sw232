# id 270000000 (Time Lane : Three Doors), field 270000000
sm.setMapTaggedObjectVisible("door0", True, 0, 0)
sm.setMapTaggedObjectVisible("door1", True, 0, 0)
sm.createQuestWithQRValue(18418, "B=32955")

# id 100051030 (Partem : Gorgonz's Place), field 100051030
sm.setMapTaggedObjectVisible("0", False, 0, 0)
sm.warp(910090308)

# 931000010
sm.avatarOriented("Effect/OnUserEff.img/guideEffect/resistanceTutorial/userTalk")
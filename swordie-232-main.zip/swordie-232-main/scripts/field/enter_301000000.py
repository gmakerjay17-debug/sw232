# id 301000000 (Crimsonheart Castle : Top of the Citadel), field 301000000

# id 450003000 (Lachelein : Lachelein Main Street), field 450003000
if sm.hasQuestCompleted(34120):
    sm.createQuestWithQRValue(34340, "enter=1")

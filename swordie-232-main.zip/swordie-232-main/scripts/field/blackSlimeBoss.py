# id 120041900 (Gold Beach : Shady Beach), field 120041900
sm.lockInGameUI(True, True)
sm.showFieldEffect("phantom/back", 0)
sm.showFieldEffect("goldBeach/blackSlimeBoss", 0)
sm.sendDelay(3000)
sm.lockInGameUI(False, True)
sm.startQuest(26511)

# Desolate Moor
# 211060000
# User enter script
# Outputs LHC's Theme Dungeon title effect.

sm.showFieldEffect("Map/Effect.img/temaD/enter/lionCastle")
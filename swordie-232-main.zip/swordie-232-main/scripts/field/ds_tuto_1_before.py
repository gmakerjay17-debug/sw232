sm.lockInGameUI(True)
sm.forcedInput(1)
sm.sendDelay(30)

sm.forcedInput(0)
sm.showFieldEffect("demonSlayer/text8", 0)
sm.sendDelay(500)

sm.showFieldEffect("demonSlayer/text9", 0)
sm.sendDelay(3000)

sm.warpInstanceIn(927000010, 1)
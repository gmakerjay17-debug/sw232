# When Yakuza Protector (9400113) dies
# Spawns the Yakuza Boss
sm.spawnMob(9400300, mob.getPosition().getX(), mob.getPosition().getY())

# id 867200480 (Abrup Basin : Outskirts of Kaptafel), field 867200480
sm.startQuest(64161)
sm.showNpcSpecialActionByTemplateId(9400588, "summon", 0)
sm.moveNpcByTemplateId(9400588, False, 500, 140)

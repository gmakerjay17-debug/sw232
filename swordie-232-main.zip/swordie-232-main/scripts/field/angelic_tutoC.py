# id 940012020 (Hidden Street : Dress-Up), field 940012020
sm.lockInGameUI(True, False)
sm.lockInGameUI(False, True)
sm.warp(400000000)
